const board = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const message = document.getElementById('message');
const scoreX = document.getElementById('scoreX');
const scoreO = document.getElementById('scoreO');
const undoBtn = document.getElementById('undo');
const restartBtn = document.getElementById('restart');
const singlePlayerBtn = document.getElementById('singlePlayer');
const multiPlayerBtn = document.getElementById('multiPlayer');
const moveSound = document.getElementById('moveSound');
const winSound = document.getElementById('winSound');
const drawSound = document.getElementById('drawSound');
const buttonClickSound = document.getElementById('buttonClickSound');
const winLineCanvas = document.getElementById('winLineCanvas');
const ctx = winLineCanvas.getContext('2d');

let currentBoard = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X';
let gameActive = true;
let isSinglePlayer = false;
let history = [];
let scores = { X: 0, O: 0 };
let cellSize = window.innerWidth <= 600 ? 80 : 100;

const winCombos = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
];

// Initialize game
function initGame() {
    cells.forEach(cell => cell.addEventListener('click', handleCellClick));
    undoBtn.addEventListener('click', handleButtonClick(undoMove));
    restartBtn.addEventListener('click', handleButtonClick(restartGame));
    singlePlayerBtn.addEventListener('click', handleButtonClick(() => startGame(true)));
    multiPlayerBtn.addEventListener('click', handleButtonClick(() => startGame(false)));
    window.addEventListener('resize', updateCanvasSize);
    updateCanvasSize();
}

// Handle button click with sound
function handleButtonClick(callback) {
    return function() {
        buttonClickSound.play();
        callback();
    };
}

// Update canvas size for responsiveness
function updateCanvasSize() {
    cellSize = window.innerWidth <= 600 ? 80 : 100;
    winLineCanvas.width = cellSize * 3 + 15;
    winLineCanvas.height = cellSize * 3 + 15;
}

// Start game
function startGame(single) {
    isSinglePlayer = single;
    restartGame();
}

// Handle cell click
function handleCellClick(e) {
    const index = e.target.dataset.index;
    if (currentBoard[index] !== '' || !gameActive || e.target.classList.contains('locked')) return;

    makeMove(index, currentPlayer);
    history.push({ index, player: currentPlayer });

    if (isSinglePlayer && gameActive && currentPlayer === 'O') {
        setTimeout(makeAIMove, 100);
    }
}

// Make move
function makeMove(index, player) {
    currentBoard[index] = player;
    cells[index].classList.add(player.toLowerCase(), 'locked');
    cells[index].style.pointerEvents = 'none';
    moveSound.play();

    const winningCombo = checkWin();
    if (winningCombo) {
        message.textContent = `Player ${player} Wins! 🏆`;
        highlightWinner(winningCombo);
        drawWinningLine(winningCombo);
        scores[player]++;
        updateScoreboard();
        gameActive = false;
        winSound.play();
        return;
    }
    if (currentBoard.every(cell => cell !== '')) {
        message.textContent = "It's a Draw! 🎉";
        gameActive = false;
        drawSound.play();
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

// Check win
function checkWin() {
    return winCombos.find(combo => combo.every(index => currentBoard[index] === currentPlayer)) || false;
}

// Highlight winner cells
function highlightWinner(combo) {
    combo.forEach(index => cells[index].classList.add('winner'));
}

// Draw winning line on canvas with animation
function drawWinningLine(combo) {
    ctx.clearRect(0, 0, winLineCanvas.width, winLineCanvas.height);
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 8;
    ctx.shadowBlur = 20;
    ctx.shadowColor = '#00ffff';

    const startIndex = combo[0];
    const endIndex = combo[2];
    const startPos = getCellPosition(startIndex);
    const endPos = getCellPosition(endIndex);

    let progress = 0;
    function animateLine() {
        ctx.clearRect(0, 0, winLineCanvas.width, winLineCanvas.height);
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        const x = startPos.x + (endPos.x - startPos.x) * progress;
        const y = startPos.y + (endPos.y - startPos.y) * progress;
        ctx.lineTo(x, y);
        ctx.stroke();

        progress += 0.05;
        if (progress < 1) {
            requestAnimationFrame(animateLine);
        }
    }
    requestAnimationFrame(animateLine);
}

// Get cell position for drawing line
function getCellPosition(index) {
    const row = Math.floor(index / 3);
    const col = index % 3;
    const offset = 7.5;
    const x = col * cellSize + cellSize / 2 + offset;
    const y = row * cellSize + cellSize / 2 + offset;
    return { x, y };
}

// Update scoreboard
function updateScoreboard() {
    scoreX.textContent = scores.X;
    scoreO.textContent = scores.O;
}

// Minimax AI Move
function makeAIMove() {
    const bestMove = minimax(currentBoard, 'O');
    if (bestMove.index !== undefined) {
        makeMove(bestMove.index, 'O');
        history.push({ index: bestMove.index, player: 'O' });
    }
}

// Minimax Algorithm
function minimax(board, player) {
    const availableCells = board.map((cell, index) => (cell === '' ? index : null)).filter(index => index !== null);

    // Check for terminal states (win/loss/draw)
    const winner = checkWinner(board);
    if (winner === 'O') return { score: 10 };
    if (winner === 'X') return { score: -10 };
    if (availableCells.length === 0) return { score: 0 };

    let bestMove;
    if (player === 'O') {
        let bestScore = -Infinity;
        for (let i = 0; i < availableCells.length; i++) {
            const index = availableCells[i];
            board[index] = 'O';
            const result = minimax(board, 'X');
            board[index] = '';
            if (result.score > bestScore) {
                bestScore = result.score;
                bestMove = { index, score: bestScore };
            }
        }
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < availableCells.length; i++) {
            const index = availableCells[i];
            board[index] = 'X';
            const result = minimax(board, 'O');
            board[index] = '';
            if (result.score < bestScore) {
                bestScore = result.score;
                bestMove = { index, score: bestScore };
            }
        }
    }
    return bestMove;
}

// Helper function to check winner for Minimax
function checkWinner(board) {
    for (const combo of winCombos) {
        if (combo.every(index => board[index] === 'O')) return 'O';
        if (combo.every(index => board[index] === 'X')) return 'X';
    }
    return null;
}

// Undo move
function undoMove() {
    if (history.length === 0 || !gameActive) return;

    const lastMove = history.pop();
    currentBoard[lastMove.index] = '';
    cells[lastMove.index].classList.remove(lastMove.player.toLowerCase(), 'locked', 'winner');
    cells[lastMove.index].style.pointerEvents = 'auto';
    currentPlayer = lastMove.player;
    message.textContent = '';
    ctx.clearRect(0, 0, winLineCanvas.width, winLineCanvas.height);
}

// Restart game
function restartGame() {
    currentBoard = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;
    history = [];
    message.textContent = '';
    cells.forEach(cell => {
        cell.classList.remove('x', 'o', 'locked', 'winner');
        cell.style.pointerEvents = 'auto';
    });
    ctx.clearRect(0, 0, winLineCanvas.width, winLineCanvas.height);
}

// Clean up event listeners on page unload to prevent memory leaks
window.addEventListener('unload', () => {
    cells.forEach(cell => cell.removeEventListener('click', handleCellClick));
    undoBtn.removeEventListener('click', handleButtonClick(undoMove));
    restartBtn.removeEventListener('click', handleButtonClick(restartGame));
    singlePlayerBtn.removeEventListener('click', handleButtonClick(() => startGame(true)));
    multiPlayerBtn.removeEventListener('click', handleButtonClick(() => startGame(false)));
    window.removeEventListener('resize', updateCanvasSize);
});

// Start the game
initGame();